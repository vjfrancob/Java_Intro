public class reto3 {
    
    public static void main(String[] args) {
        new myFrame();
    }
}
